# ZtexBTCMiner
BTCMiner is a Bitcoin Miner software which allows you to make money with your ZTEX USB-FPGA Module. Since these FPGA Boards contain an USB interface no additional hardware (like JTAG programmer) is required and low cost FPGA-clusters can be build using standard USB hubs.
